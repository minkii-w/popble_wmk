package com.popble.domain;


public enum Role {

	ADMIN, MEMBER, COMPANY
}
