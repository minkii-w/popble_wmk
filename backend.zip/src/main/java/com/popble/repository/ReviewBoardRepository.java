//package com.popble.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.popble.domain.ReviewBoard;
//
//public interface ReviewBoardRepository extends JpaRepository<ReviewBoard, Long>{
//
//}
