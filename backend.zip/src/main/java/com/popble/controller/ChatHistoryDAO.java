package com.popble.controller;

import org.springframework.stereotype.Component;


public class ChatHistoryDAO {


}
