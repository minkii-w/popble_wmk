//package com.popble.controller;
//
//import java.util.List;
//
//import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.messaging.handler.annotation.MessageMapping;
//import org.springframework.messaging.handler.annotation.SendTo;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.popble.domain.ChatMessage;
//
//@RestController
//@CrossOrigin
//public class ChatController {
//<<<<<<< HEAD
//	
////	private ChatService chatService;
//	
//=======
//
//
////	private ChatService chatService;
//
//>>>>>>> bf0e1f351dff7179cfbaa1096edaf439d55cab5f
//}
