//package com.popble.dto;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.fasterxml.jackson.annotation.JsonManagedReference;
//import com.popble.domain.PopupCategory;
//import com.popble.domain.Category;
//import com.popble.domain.Category.CategoryType;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.EnumType;
//import jakarta.persistence.Enumerated;
//import jakarta.persistence.Id;
//import jakarta.persistence.OneToMany;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class CategoryDTO {
//		private Integer id;
//		private String name;
//}
