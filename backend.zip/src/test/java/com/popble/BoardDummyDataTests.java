package com.popble;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BoardDummyDataTests {

	@Test
	public void createBoardTests() {
		
	}
}
